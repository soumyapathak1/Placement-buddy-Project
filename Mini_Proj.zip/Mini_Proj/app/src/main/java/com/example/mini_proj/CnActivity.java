package com.example.mini_proj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CnActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cn);
    }
}