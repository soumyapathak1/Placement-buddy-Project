package com.example.mini_proj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DbmsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dbms);
    }
}